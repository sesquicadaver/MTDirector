"""Offline regression tests; never connect to a router."""
import contextlib
from datetime import date
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

import mikrotik_audit as audit


class CoreTests(unittest.TestCase):
    def test_version_branch_regression(self):
        self.assertEqual(audit.september_2026("7.23.4"), "PATCHED")
        self.assertEqual(audit.september_2026("7.24.1"), "AFFECTED")
        self.assertEqual(audit.september_2026("7.24.2"), "PATCHED")

    def test_prerelease_not_assumed_patched(self):
        self.assertEqual(audit.september_2026("7.24rc1"), "UNKNOWN")
        self.assertEqual(audit.september_2026("7.25beta2"), "AFFECTED")
        self.assertEqual(audit.september_2026("7.25beta3"), "PATCHED")

    def test_unknown_boolean_not_false(self):
        self.assertIsNone(audit.boolean(None))
        self.assertIsNone(audit.boolean("unexpected"))
        self.assertFalse(audit.boolean("false"))
        self.assertTrue(audit.boolean("yes"))

    def test_invalid_version(self):
        self.assertIsNone(audit.version("7.24.2\nscript error"))
        self.assertEqual(audit.september_2026("8.0"), "UNKNOWN")

    def test_version_matrix(self):
        cases = {"6.49.20": "AFFECTED", "6.49.21 (long-term)": "PATCHED",
                 "7.23.3": "AFFECTED", "7.23.5": "PATCHED", "7.24": "AFFECTED",
                 "7.24.2 (stable)": "PATCHED", "5.26": "UNKNOWN",
                 "7.23.4rc1": "UNKNOWN", "7.25rc1": "UNKNOWN"}
        for version, expected in cases.items():
            with self.subTest(version=version):
                self.assertEqual(audit.september_2026(version), expected)

    def test_version_format_is_strict(self):
        for text in (None, "", "v7.24.2", "7.24.2 script error", "7", "7.24.2.1", "7.24.2; /quit"):
            with self.subTest(text=text):
                self.assertIsNone(audit.version(text))

    def test_no_numeric_boolean_coercion(self):
        for value in (0, 1, [], {}, "0", "1", "auto"):
            self.assertIsNone(audit.boolean(value))


def row(**values):
    return {"_schema": 1, **values}


def snapshot(**data):
    return {"schema": 1, "host": "router.example", "routeros_version": "7.24.2",
            "collected_at": "2026-09-06T12:00:00+00:00", "data": data, "errors": {}}


def wire(value):
    """Synthetic protocol fixture; not an emulation or execution of RouterOS."""
    if isinstance(value, str):
        return "@MT-STR-1@" + value
    if isinstance(value, list):
        return [wire(item) for item in value]
    if isinstance(value, dict):
        return {key: wire(item) for key, item in value.items()}
    return value


def frame(data=None, errors=(), end=True):
    lines = [audit.MARKER + key + ":" + json.dumps(wire(value), ensure_ascii=False) for key, value in (data or {}).items()]
    lines += [audit.MARKER + key + ":ERROR" for key in errors]
    if end:
        lines += [audit.MARKER + "END"]
    return ("\r\n".join(lines) + "\r\n").encode()


def probe_response():
    return b'{"_schema":1,"text":"@MT-STR-1@001","truth":true,"falsehood":false,"number":7,"items":["@MT-STR-1@001","@MT-STR-1@false","@MT-STR-1@@MT-STR-1@literal"],"empty":"@MT-STR-1@"}\r\n'


def chunk_replies(sections):
    replies = []
    for _script, keys in audit.collection_commands():
        data = {key: sections[key] for key in keys if key in sections}
        missing = tuple(key for key in keys if key not in sections)
        replies.append((0, frame(data, errors=missing), b""))
    return replies


class WireCompatibilityTests(unittest.TestCase):
    def test_collector_avoids_unsupported_7_16_option(self):
        self.assertNotIn("json.no-string-conversion", audit.collection_command())

    def test_numeric_strings_and_literal_prefix_preserved(self):
        payload = {"_schema": 1, "name": "@MT-STR-1@001", "port": 22,
                   "address": ["@MT-STR-1@192.0.2.0/24", "@MT-STR-1@2001:db8::/64"],
                   "disabled": False, "literal": "@MT-STR-1@@MT-STR-1@001"}
        raw = (audit.MARKER + "services:" + json.dumps([payload]) + "\n" + audit.MARKER + "END\n").encode()
        data, errors = audit.parse_collection(raw)
        self.assertNotIn("services", errors)
        self.assertEqual(data["services"][0], row(name="001", port=22, address=["192.0.2.0/24", "2001:db8::/64"],
                                                disabled=False, literal="@MT-STR-1@001"))

    def test_unprotected_string_is_quarantined(self):
        raw = (audit.MARKER + 'services:[{"_schema":1,"name":"telnet","disabled":false}]\n' + audit.MARKER + "END\n").encode()
        data, errors = audit.parse_collection(raw)
        self.assertNotIn("services", data)
        self.assertIn("services", errors)

    def test_unprotected_list_string_is_quarantined(self):
        payload = [{"_schema": 1, "name": "@MT-STR-1@ssh", "address": ["192.0.2.0/24"]}]
        raw = (audit.MARKER + "services:" + json.dumps(payload) + "\n" + audit.MARKER + "END\n").encode()
        data, errors = audit.parse_collection(raw)
        self.assertNotIn("services", data)
        self.assertIn("services", errors)

    def test_nested_property_array_is_quarantined(self):
        data, errors = audit.parse_collection(frame({"services": [row(name="ssh", address=[["192.0.2.0/24"]])]}))
        self.assertNotIn("services", data)
        self.assertIn("services", errors)

    def test_legacy_wire_frame_not_misinterpreted(self):
        with self.assertRaises(audit.AuditError):
            audit.parse_collection(b'@MT-AUDIT-1@users:[]\n@MT-AUDIT-1@END\n')

    def test_special_strings_round_trip(self):
        for name in ("", "0", "1e3", "000000000000000001", "true", "false", "null", 'a"b\\c\n', "Інтерфейс", "@MT-STR-1@"):
            with self.subTest(name=name):
                data, errors = audit.parse_collection(frame({"users": [row(name=name)]}))
                self.assertNotIn("users", errors)
                self.assertEqual(data["users"][0]["name"], name)

    def test_probe_uses_only_local_values_and_basic_json(self):
        command = audit.json_probe_command()
        self.assertNotIn("json.no-string-conversion", command)
        self.assertNotRegex(command, r"\[/[a-z]")
        self.assertNotIn(":global", command)
        self.assertNotIn(":parse", command)
        self.assertLess(len(command.encode()), 4096)

    def test_7_16_collects_services_after_valid_probe(self):
        args = audit.parser().parse_args(["--host", "192.0.2.1", "--user", "auditor"])
        content = {"resource": row(version="7.16.2 (stable)"),
                   "services": [row(name="telnet", disabled=False, port=23, address=""),
                                row(name="www", disabled=True, port=80),
                                row(name="api-ssl", disabled=False, port=8729, address="", certificate="none")]}
        responses = [(0, b"7.16.2 (stable)", b""), (0, probe_response(), b"")] + chunk_replies(content)
        with patch.object(audit, "run_bounded", side_effect=responses) as run:
            result = audit.collect(args)
        self.assertEqual(run.call_count, 2 + len(audit.collection_commands()))
        for call in run.call_args_list:
            self.assertNotIn("json.no-string-conversion", call.args[0][-1])
            self.assertNotIn("count-only", call.args[0][-1])
        self.assertNotIn("structured_collection", result["errors"])
        self.assertEqual(result["data"]["services"], content["services"])
        report = audit.Checks(result).run()
        plaintext = [f["evidence"]["name"] for f in report["findings"] if f["id"] == "PLAINTEXT-SERVICE"]
        self.assertEqual(plaintext, ["telnet"])

    def test_second_chunk_failure_keeps_first_chunk(self):
        args = audit.parser().parse_args(["--host", "192.0.2.1", "--user", "auditor"])
        chunks = audit.collection_commands()
        self.assertGreaterEqual(len(chunks), 2)
        first_keys = chunks[0][1]
        self.assertIn("services", first_keys)
        services = [row(name="telnet", disabled=False, port=23, address="")]
        first = frame({"services": services},
                      errors=tuple(key for key in first_keys if key != "services"))
        fail = (1, b"expected end of command (line 1 column 18400)\r\n", b"")
        responses = [(0, b"7.16.2", b""), (0, probe_response(), b""),
                     (0, first, b"")] + [fail] * (len(chunks) - 1)
        with patch.object(audit, "run_bounded", side_effect=responses) as run:
            result = audit.collect(args)
        self.assertEqual(run.call_count, 2 + len(chunks))
        self.assertEqual(result["data"]["services"], services)
        self.assertIn("18400", result["errors"]["structured_collection"])
        self.assertIn(chunks[1][1][0], result["errors"])
        self.assertIn("routerboard", result["errors"])

    def test_isolated_routerboard_failure_keeps_other_sections(self):
        args = audit.parser().parse_args(["--host", "192.0.2.1", "--user", "auditor"])
        chunks = audit.collection_commands()
        self.assertEqual(chunks[-1][1], ("routerboard",))
        content = {"resource": row(version="7.16.2 (stable)"),
                   "services": [row(name="telnet", disabled=False, port=23, address="")],
                   "dns": row(**{"allow-remote-requests": False, "verify-doh-cert": False})}
        replies = chunk_replies(content)
        replies[-1] = (1, b"syntax error (line 1 column 26)\r\n", b"")
        responses = [(0, b"7.16.2 (stable)", b""), (0, probe_response(), b"")] + replies
        with patch.object(audit, "run_bounded", side_effect=responses) as run:
            result = audit.collect(args)
        self.assertEqual(run.call_count, 2 + len(chunks))
        self.assertEqual(result["data"]["services"], content["services"])
        self.assertEqual(result["data"]["dns"], content["dns"])
        self.assertNotIn("routerboard", result["data"])
        self.assertIn("routerboard", result["errors"])
        self.assertIn("column 26", result["errors"]["structured_collection"])

    def test_probe_rejects_numeric_coercion_before_collection(self):
        args = audit.parser().parse_args(["--host", "192.0.2.1", "--user", "auditor"])
        raw = probe_response().replace(b'"@MT-STR-1@001"', b"1.000000")
        with patch.object(audit, "run_bounded", side_effect=[(0, b"7.16.2", b""), (0, raw, b"")]) as run:
            result = audit.collect(args)
        self.assertEqual(run.call_count, 2)
        self.assertEqual(result["data"], {})
        self.assertIn("JSON-проба", result["errors"]["structured_collection"])

    def test_probe_rejects_boolean_coercion(self):
        args = audit.parser().parse_args(["--host", "192.0.2.1", "--user", "auditor"])
        raw = probe_response().replace(b'"truth":true', b'"truth":1')
        with patch.object(audit, "run_bounded", side_effect=[(0, b"7.16.2", b""), (0, raw, b"")]):
            result = audit.collect(args)
        self.assertIn("structured_collection", result["errors"])

    def test_probe_rejects_stderr_and_stops_before_collection(self):
        args = audit.parser().parse_args(["--host", "192.0.2.1", "--user", "auditor"])
        with patch.object(audit, "run_bounded", side_effect=[(0, b"7.16.2", b""),
                                                           (0, probe_response(), b"permission denied")]) as run:
            result = audit.collect(args)
        self.assertEqual(run.call_count, 2)
        self.assertIn("permission denied", result["errors"]["structured_collection"])
        self.assertEqual(result["data"], {})

    def test_version_change_after_probe_quarantines_data(self):
        args = audit.parser().parse_args(["--host", "192.0.2.1", "--user", "auditor"])
        content = {"resource": row(version="7.17"), "services": [row(name="telnet", disabled=True)]}
        responses = [(0, b"7.16.2", b""), (0, probe_response(), b"")] + chunk_replies(content)
        with patch.object(audit, "run_bounded", side_effect=responses):
            result = audit.collect(args)
        self.assertIn("consistency", result["errors"])
        self.assertIsNone(audit.Checks(result).table("services"))

    def test_collection_syntax_error_after_probe_is_diagnostic(self):
        args = audit.parser().parse_args(["--host", "192.0.2.1", "--user", "auditor"])
        for code in (0, 1):
            with self.subTest(code=code):
                fail = (code, b"syntax error (line 1 column 944)\r\n", b"")
                n = len(audit.collection_commands())
                responses = [(0, b"7.16.2", b""), (0, probe_response(), b"")] + [fail] * n
                with patch.object(audit, "run_bounded", side_effect=responses):
                    result = audit.collect(args)
                self.assertEqual(result["data"], {})
                self.assertIn("column 944", result["errors"]["structured_collection"])
                self.assertIn(f"rc={code}", result["errors"]["structured_collection"])

    def test_global_deadline_includes_probe(self):
        args = audit.parser().parse_args(["--host", "192.0.2.1", "--user", "auditor"])
        with patch.object(audit.time, "monotonic", side_effect=[0, 2, 121]), \
                patch.object(audit, "run_bounded", side_effect=[(0, b"7.16.2", b""), (0, probe_response(), b"")]) as run:
            result = audit.collect(args)
        self.assertEqual(run.call_count, 2)
        self.assertEqual(result["data"], {})
        self.assertIn("час", result["errors"]["structured_collection"])


class ProtocolTests(unittest.TestCase):
    def test_empty_successful_table_is_distinct_from_failure(self):
        data, errors = audit.parse_collection(frame({"users": []}, errors=("services",)))
        self.assertEqual(data["users"], [])
        self.assertIn("services", errors)
        self.assertNotIn("services", data)

    def test_truncated_output_rejected(self):
        with self.assertRaises(audit.AuditError):
            audit.parse_collection(frame({"users": []}, end=False))

    def test_extra_stdout_rejected(self):
        for raw in (b"bad command name\n", b"banner\n" + frame(), frame() + b"failure\n"):
            with self.assertRaises(audit.AuditError):
                audit.parse_collection(raw)

    def test_missing_data_is_unknown(self):
        data, errors = audit.parse_collection(frame())
        self.assertEqual(data, {})
        self.assertEqual(set(errors), set(audit.SECTIONS))

    def test_duplicate_section_rejected(self):
        raw = frame({"users": []}, end=False) + frame({"users": []})
        with self.assertRaises(audit.AuditError):
            audit.parse_collection(raw)

    def test_duplicate_json_key_rejected(self):
        with self.assertRaises(audit.AuditError):
            audit.strict_json('{"disabled":true,"disabled":false}')

    def test_nonfinite_json_rejected(self):
        for text in ("NaN", "Infinity", "-Infinity"):
            with self.assertRaises(audit.AuditError):
                audit.strict_json(text)

    def test_unknown_marker_rejected(self):
        with self.assertRaises(audit.AuditError):
            audit.parse_collection(frame({"invented": []}))

    def test_invalid_utf8_rejected(self):
        with self.assertRaises(audit.AuditError):
            audit.parse_collection(b"\xff" + frame())

    def test_malformed_json_quarantines_section(self):
        data, errors = audit.parse_collection((audit.MARKER + "users:[bad]\n" + audit.MARKER + "END\n").encode())
        self.assertNotIn("users", data)
        self.assertIn("users", errors)

    def test_unicode_line_separator_does_not_break_json(self):
        data, _ = audit.parse_collection(frame({"users": [row(name="a\u2028b")]}))
        self.assertEqual(data["users"][0]["name"], "a\u2028b")

    def test_marker_in_value_not_a_new_record(self):
        name = "safe\n" + audit.MARKER + "END"
        data, _ = audit.parse_collection(frame({"users": [row(name=name)]}))
        self.assertEqual(data["users"][0]["name"], name)

    def test_invalid_schema_rejected(self):
        for value in ({}, {"_schema": True}, row(name=[]), row(name={}), row(bad=float("inf"))):
            with self.assertRaises(audit.AuditError):
                audit.validate_section("users", [value])

    def test_row_limit_enforced(self):
        with self.assertRaises(audit.AuditError):
            audit.validate_section("users", [row()] * (audit.MAX_ROWS + 1))

    def test_output_limit_enforced(self):
        with self.assertRaises(audit.AuditError):
            audit.parse_collection(b"x" * (audit.MAX_BYTES + 1))

    def test_command_contains_only_fixed_read_paths(self):
        chunks = audit.collection_commands()
        command = audit.collection_command()
        self.assertGreaterEqual(len(chunks), 2)
        covered = []
        for script, keys in chunks:
            self.assertNotIn("\n", script)
            self.assertLessEqual(len(script), audit.MAX_SSH_SCRIPT)
            self.assertNotIn("count-only", script)
            covered.extend(keys)
        self.assertEqual(set(covered), set(audit.SECTIONS))
        self.assertEqual(len(covered), len(audit.SECTIONS))
        self.assertEqual(chunks[-1][1], ("routerboard",))
        for script, keys in chunks[:-1]:
            self.assertNotIn("/system/routerboard", script)
            self.assertNotIn("routerboard", keys)
        self.assertNotIn("\n", command)
        self.assertNotIn("count-only", command)
        paths = re.findall(r"\[(/[a-z0-9/-]+)", command)
        allowed = {menu + "/find" for menu, _ in audit.TABLES.values()}
        allowed |= {menu + "/get" for menu, _ in audit.TABLES.values()}
        allowed |= {menu + "/get" for menu, _ in audit.SCALARS.values()}
        self.assertEqual(set(paths), allowed)
        self.assertNotIn("/print", command)
        for forbidden in ("/set ", "/add ", "/remove ", "/enable", "/disable", ":execute", ":parse", ":global", "file-name=", "/run ", "/fetch "):
            self.assertNotIn(forbidden, command)
        self.assertIn("($auditResult, {$auditOut})", command)

    def test_count_only_stdout_is_not_a_successful_frame(self):
        raw = b"8\n" + frame({"users": []})
        with self.assertRaises(audit.AuditError):
            audit.parse_collection(raw, expected_keys=("users",))

    def test_chunk_parser_does_not_require_other_sections(self):
        data, errors = audit.parse_collection(frame({"users": []}), expected_keys=("users",))
        self.assertEqual(data["users"], [])
        self.assertEqual(errors, {})

    def test_secret_fields_not_projected(self):
        command = audit.collection_command()
        for field in ("password", "private-key", "secret", "source", "on-event", "message", "community", "use-doh-server"):
            self.assertNotIn('$auditOut->"' + field + '"', command)

    def test_generated_limit_cannot_inject_command(self):
        for value in (0, -1, 1001, True, '1; /system/reboot'):
            with self.assertRaises(audit.AuditError):
                audit.collection_command(value)


class ConfigurationTests(unittest.TestCase):
    def test_disabled_plaintext_not_warned(self):
        check = audit.Checks(snapshot(services=[row(name="telnet", disabled=True)]))
        check.services()
        self.assertEqual([f["status"] for f in check.findings], ["PASS"])

    def test_ssl_names_not_mistaken_for_plaintext(self):
        check = audit.Checks(snapshot(services=[row(name=x, disabled=False, port=443, address="10.0.0.0/24", certificate="valid-name")
                                             for x in ("www-ssl", "api-ssl")]))
        check.services()
        self.assertNotIn("PLAINTEXT-SERVICE", {x["id"] for x in check.findings})

    def test_plaintext_enabled_is_a_finding(self):
        check = audit.Checks(snapshot(services=[row(name="api", disabled=False, port=8728, address="")]))
        check.services()
        self.assertIn("PLAINTEXT-SERVICE", {x["id"] for x in check.findings})

    def test_missing_service_state_unknown(self):
        check = audit.Checks(snapshot(services=[row(name="telnet")]))
        check.services()
        self.assertEqual(check.findings[0]["status"], "UNKNOWN")

    def test_boolean_service_port_rejected(self):
        check = audit.Checks(snapshot())
        check.service_firewall(row(name="ssh", port=True))
        self.assertEqual(check.findings[0]["id"], "SERVICE-PORT")

    def test_admin_exact_name_only(self):
        check = audit.Checks(snapshot(users=[row(name="administrator", disabled=False, address="10.0.0.1", group="read")]))
        check.users()
        self.assertNotIn("DEFAULT-ADMIN", {x["id"] for x in check.findings})

    def test_disabled_admin_not_a_warning(self):
        check = audit.Checks(snapshot(users=[row(name="admin", disabled=True)]))
        check.users()
        self.assertEqual(check.findings, [])

    def test_admin_not_critical(self):
        check = audit.Checks(snapshot(users=[row(name="admin", disabled=False)]))
        check.users()
        finding = next(x for x in check.findings if x["id"] == "DEFAULT-ADMIN")
        self.assertEqual((finding["status"], finding["severity"]), ("HARDENING", "low"))

    def test_ops_not_proof_of_compromise(self):
        check = audit.Checks(snapshot(users=[row(name="ops", disabled=False)]))
        check.users()
        self.assertEqual(next(x for x in check.findings if x["id"] == "IOC-OPS")["status"], "REVIEW")

    def test_empty_users_not_safe(self):
        check = audit.Checks(snapshot(users=[]))
        check.users()
        self.assertEqual(check.findings[0]["status"], "UNKNOWN")

    def test_flagged_false_not_clean_bill(self):
        check = audit.Checks(snapshot(device_mode=row(flagged=False)))
        check.compromise()
        self.assertEqual(check.findings[0]["status"], "OBSERVED")

    def test_flagged_true_indicator(self):
        check = audit.Checks(snapshot(device_mode=row(flagged=True)))
        check.compromise()
        self.assertEqual(check.findings[0]["status"], "INDICATOR")

    def test_missing_device_mode_unknown(self):
        check = audit.Checks(snapshot())
        check.compromise()
        self.assertEqual(check.findings[0]["status"], "UNKNOWN")

    def test_dns_enabled_not_proof_of_open_resolver(self):
        check = audit.Checks(snapshot(dns=row(**{"allow-remote-requests": True})))
        check.configuration()
        self.assertEqual(check.findings[0]["status"], "REVIEW")

    def test_negated_group_policy_not_a_capability(self):
        check = audit.Checks(snapshot(users=[row(name="auditor", disabled=False, group="audit")],
                                     groups=[row(name="audit", policy="read,ssh,!write,!policy,!sensitive")]))
        check.users()
        self.assertNotIn("GROUP-CAPABILITIES", {x["id"] for x in check.findings})

    def test_acl_requires_explicit_trust(self):
        check = audit.Checks(snapshot(), trusted=("10.0.0.0/24", "2001:db8:1::/64"))
        for value, state in (("", "UNRESTRICTED"), (None, "UNKNOWN"), ("::/0", "UNRESTRICTED"),
                             ("10.0.0.2/32", "TRUSTED_ONLY"), ("10.0.0.0/8", "OUTSIDE_TRUSTED"),
                             ("2001:db8:1::2", "TRUSTED_ONLY"), ("2001:db8:2::1", "OUTSIDE_TRUSTED"),
                             ("!10.0.0.0/24", "UNKNOWN")):
            self.assertEqual(check.scope(value), state)
        self.assertEqual(audit.Checks(snapshot()).scope("192.168.88.0/24"), "RESTRICTED_UNVERIFIED")

    def test_conflicting_collection_never_used(self):
        value = snapshot(device_mode=row(flagged=False))
        value["errors"]["consistency"] = "changed"
        check = audit.Checks(value)
        check.versions()
        check.compromise()
        self.assertFalse(any(f["status"] == "PASS" for f in check.findings))


def firewall_checks(rules, **data):
    return audit.Checks(snapshot(ipv4_filter=rules, interfaces=[row(name="wan"), row(name="lan")], **data), untrusted=("wan",))


def rule(action, **properties):
    return row(chain="input", action=action, disabled=False, **properties)


class FirewallTests(unittest.TestCase):
    def evaluate(self, rules):
        return firewall_checks(rules).firewall(4, "wan", "tcp", 22)[0]

    def test_terminal_drop(self):
        self.assertEqual(self.evaluate([rule("drop")]), "BLOCK")

    def test_empty_input_implicit_accept(self):
        self.assertEqual(self.evaluate([]), "POSSIBLE")

    def test_drop_before_accept(self):
        self.assertEqual(self.evaluate([rule("drop"), rule("accept")]), "BLOCK")

    def test_accept_before_drop(self):
        self.assertEqual(self.evaluate([rule("accept"), rule("drop")]), "POSSIBLE")

    def test_conditional_accept_never_hidden(self):
        self.assertEqual(self.evaluate([rule("accept", **{"src-address-list": "mgmt"}), rule("drop")]), "POSSIBLE")

    def test_conditional_drop_not_unconditional(self):
        self.assertEqual(self.evaluate([rule("drop", limit="10,20:packet")]), "POSSIBLE")

    def test_future_matcher_never_ignored(self):
        self.assertEqual(self.evaluate([rule("drop", **{"future-option": True})]), "POSSIBLE")

    def test_jump_is_unknown(self):
        self.assertEqual(self.evaluate([rule("jump", **{"jump-target": "custom"}), rule("drop")]), "UNKNOWN")

    def test_return_is_unknown(self):
        self.assertEqual(self.evaluate([rule("return"), rule("drop")]), "UNKNOWN")

    def test_established_accept_does_not_match_new(self):
        self.assertEqual(self.evaluate([rule("accept", **{"connection-state": ["established", "related"]}), rule("drop")]), "BLOCK")

    def test_disabled_drop_not_used(self):
        self.assertEqual(self.evaluate([row(chain="input", action="drop", disabled=True)]), "POSSIBLE")

    def test_missing_disabled_never_proves_block(self):
        self.assertEqual(self.evaluate([row(chain="input", action="drop")]), "POSSIBLE")

    def test_invalid_drop_not_used(self):
        self.assertEqual(self.evaluate([rule("drop", invalid=True)]), "POSSIBLE")

    def test_malformed_invalid_state_not_unconditional(self):
        self.assertEqual(self.evaluate([rule("drop", invalid="unexpected")]), "POSSIBLE")

    def test_missing_chain_not_ignored_before_drop(self):
        self.assertEqual(self.evaluate([row(action="accept", disabled=False), rule("drop")]), "UNKNOWN")

    def test_unrecognized_connection_state_not_ignored(self):
        self.assertEqual(self.evaluate([rule("accept", **{"connection-state": "future-state"}), rule("drop")]), "POSSIBLE")

    def test_other_interface_not_match(self):
        self.assertEqual(self.evaluate([rule("accept", **{"in-interface": "lan"}), rule("drop")]), "BLOCK")

    def test_negated_interface_matches(self):
        self.assertEqual(self.evaluate([rule("drop", **{"in-interface": "!lan"})]), "BLOCK")

    def test_udp_drop_does_not_block_tcp(self):
        self.assertEqual(self.evaluate([rule("drop", protocol="udp")]), "POSSIBLE")

    def test_protocol_zero_not_all(self):
        self.assertEqual(self.evaluate([rule("drop", protocol="0")]), "POSSIBLE")

    def test_unknown_protocol_not_unconditional(self):
        self.assertEqual(self.evaluate([rule("drop", protocol="!new-protocol")]), "POSSIBLE")

    def test_port_and_protocol(self):
        self.assertEqual(self.evaluate([rule("drop", protocol="6", **{"dst-port": "20-23,443"})]), "BLOCK")
        self.assertEqual(self.evaluate([rule("drop", **{"dst-port": "443"})]), "POSSIBLE")

    def test_missing_ipv6_rules_unknown(self):
        self.assertEqual(firewall_checks([]).firewall(6, "wan", "tcp", 22)[0], "UNKNOWN")

    def test_log_is_nonterminal(self):
        self.assertEqual(self.evaluate([rule("log"), rule("drop")]), "BLOCK")

    def test_failed_collection_not_empty_chain(self):
        checks = firewall_checks([])
        checks.snapshot["errors"]["ipv4_filter"] = "permission denied"
        self.assertEqual(checks.firewall(4, "wan", "tcp", 22)[0], "UNKNOWN")

    def test_port_parser(self):
        for value in ("!22", "80-20", "0", "65536", "22;reboot", None):
            self.assertIsNone(audit.port_match(value, 22))
        self.assertTrue(audit.port_match(["20-23", "80"], 22))
        self.assertFalse(audit.port_match("80,443", 22))


class InterfaceTests(unittest.TestCase):
    def checks(self, lists=(), members=()):
        return firewall_checks([], lists=list(lists), members=list(members))

    def test_predefined_lists(self):
        checks = self.checks()
        self.assertEqual(checks.list_members("none"), set())
        self.assertEqual(checks.list_members("all"), {"wan", "lan"})
        self.assertEqual(checks.list_members("!none"), {"wan", "lan"})

    def test_unknown_list_unknown(self):
        self.assertIsNone(self.checks().list_members("WAN"))

    def test_explicit_after_exclude(self):
        checks = self.checks([row(name="test", include="all", exclude="all")], [row(list="test", interface="wan")])
        self.assertEqual(checks.list_members("test"), {"wan"})

    def test_recursive_lists_cycle_unknown(self):
        checks = self.checks([row(name="A", include="B"), row(name="B", include="A")])
        self.assertIsNone(checks.list_members("A"))

    def test_nested_lists(self):
        checks = self.checks([row(name="A", include="B"), row(name="B")], [row(list="B", interface="wan")])
        self.assertEqual(checks.list_members("A"), {"wan"})

    def test_missing_interface_unknown(self):
        checks = self.checks([row(name="A")], [row(list="A", interface="missing")])
        self.assertIsNone(checks.list_members("A"))

    def test_mac_none_not_reported_active(self):
        checks = audit.Checks(snapshot(mac_winbox=row(**{"allowed-interface-list": "none"})))
        checks.layer2()
        self.assertEqual(checks.findings[0]["status"], "PASS")

    def test_bridge_untrusted_overlap_detected(self):
        checks = audit.Checks(snapshot(interfaces=[row(name="br"), row(name="guest")],
                                      lists=[row(name="MGMT")], members=[row(list="MGMT", interface="br")],
                                      bridge_ports=[row(bridge="br", interface="guest", disabled=False)],
                                      mac_winbox=row(**{"allowed-interface-list": "MGMT"})), untrusted=("guest",))
        checks.layer2()
        self.assertEqual(checks.findings[0]["status"], "POTENTIAL_EXPOSURE")


class ProcessTests(unittest.TestCase):
    def test_diagnostic_bounds_and_redacts_framed_data(self):
        raw = frame({"users": [row(name="private-marker")]}) + b"syntax error (line 1 column 944)\r\n"
        diagnostic = audit.ssh_diagnostic("збір", 1, raw, b"permission denied\x1b[31m")
        self.assertIn("column 944", diagnostic)
        self.assertIn("permission denied", diagnostic)
        self.assertNotIn("private-marker", diagnostic)
        self.assertNotIn("\x1b", diagnostic)
        self.assertLess(len(audit.ssh_diagnostic("збір", 1, b"x" * 100000, b"y" * 100000)), 1500)

    def test_empty_error_has_return_code(self):
        self.assertIn("rc=1", audit.ssh_diagnostic("збір", 1, b"", b""))

    def test_routeros_stdout_error_is_reported_with_exit_code(self):
        args = audit.parser().parse_args(["--host", "192.0.2.1", "--user", "auditor"])
        responses = [(0, b"7.16.2 (stable)", b""),
                     (1, b"syntax error (line 1 column 944)\r\n", b"")]
        with patch.object(audit, "run_bounded", side_effect=responses):
            result = audit.collect(args)
        diagnostic = result["errors"]["structured_collection"]
        self.assertIn("rc=1", diagnostic)
        self.assertIn("stdout=syntax error (line 1 column 944)", diagnostic)
        self.assertEqual(result["data"], {})

    def test_version_stdout_failure_not_empty(self):
        args = audit.parser().parse_args(["--host", "192.0.2.1", "--user", "auditor"])
        with patch.object(audit, "run_bounded", return_value=(1, b"not enough permissions (9)", b"")):
            with self.assertRaisesRegex(audit.AuditError, r"rc=1.*not enough permissions"):
                audit.collect(args)

    def test_drains_both_streams(self):
        code, out, err = audit.run_bounded([sys.executable, "-c", "import sys; sys.stdout.write('a'*70000); sys.stderr.write('b'*70000)"], 5)
        self.assertEqual(code, 0)
        self.assertEqual(len(out), 70000)
        self.assertEqual(len(err), 70000)

    def test_output_bound(self):
        with self.assertRaises(audit.AuditError):
            audit.run_bounded([sys.executable, "-c", "print('a'*200000)"], 5, 1024)

    def test_total_deadline(self):
        start = time.monotonic()
        with self.assertRaises(audit.AuditError):
            audit.run_bounded([sys.executable, "-c", "import time; time.sleep(5)"], 0.15)
        self.assertLess(time.monotonic() - start, 3)

    def test_nonzero_exit_preserved(self):
        code, _, _ = audit.run_bounded([sys.executable, "-c", "raise SystemExit(7)"], 5)
        self.assertEqual(code, 7)

    def test_stderr_means_error_even_with_zero_status(self):
        args = audit.parser().parse_args(["--host", "192.0.2.1", "--user", "auditor"])
        with patch.object(audit, "run_bounded", return_value=(0, b"7.24.2", b"error")):
            with self.assertRaises(audit.AuditError):
                audit.collect(args)

    def test_second_command_failure_preserves_version_only(self):
        args = audit.parser().parse_args(["--host", "192.0.2.1", "--user", "auditor"])
        with patch.object(audit, "run_bounded", side_effect=[(0, b"7.24.2", b""), (1, b"", b"failure")]):
            result = audit.collect(args)
        self.assertEqual(result["routeros_version"], "7.24.2")
        self.assertEqual(result["data"], {})
        self.assertIn("structured_collection", result["errors"])

    def test_legacy_collect_only_one_version_command(self):
        args = audit.parser().parse_args(["--host", "192.0.2.1", "--user", "auditor"])
        with patch.object(audit, "run_bounded", return_value=(0, b"6.49.21", b"")) as run:
            result = audit.collect(args)
        self.assertEqual(run.call_count, 1)
        self.assertIn("structured_collection", result["errors"])

    def test_host_validation(self):
        for host in ("192.0.2.1", "2001:db8::1", "router.example"):
            self.assertTrue(audit.valid_host(host))
        for host in ("-oProxyCommand=x", "a;cmd", "a\nb", "user@host", "$(reboot)", "fe80::1%eth0"):
            self.assertFalse(audit.valid_host(host))

    def test_ssh_configuration_is_strict_without_connection(self):
        args = audit.parser().parse_args(["--host", "192.0.2.1", "--user", "auditor"])
        argv = audit.ssh_argv(args, audit.VERSION_COMMAND)
        self.assertIn("StrictHostKeyChecking=yes", argv)
        self.assertIn("BatchMode=yes", argv)
        self.assertIn("ForwardAgent=no", argv)
        self.assertIn("ControlPath=none", argv)
        self.assertEqual(argv[-3:], ["--", "192.0.2.1", audit.VERSION_COMMAND])
        self.assertNotIn("AutoAddPolicy", str(argv))
        # ssh -G evaluates config only. No socket, DNS lookup, or router access.
        config = subprocess.run([argv[0], "-G", *argv[1:-1]], capture_output=True, text=True, timeout=5)
        self.assertEqual(config.returncode, 0, config.stderr)
        self.assertIn("stricthostkeychecking true", config.stdout)
        self.assertIn("batchmode yes", config.stdout)


class ReportTests(unittest.TestCase):
    def test_v1_snapshot_is_decoded_only_once(self):
        data = snapshot(users=[row(name="001", group="@MT-STR-1@admins")])
        data["tool_version"] = "1.0.0"
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "v1-snapshot.json"
            audit.write_private(path, data)
            restored = audit.read_snapshot(path)
        self.assertEqual(restored["data"], data["data"])

    def test_uncollected_interfaces_do_not_claim_not_found(self):
        report = audit.Checks(snapshot(), untrusted=("ether3", "ether4")).run()
        ids = {f["id"] for f in report["findings"]}
        self.assertNotIn("INTERFACE-NOT-FOUND", ids)
        self.assertIn("INTERFACE-INVENTORY", ids)

    def test_collected_inventory_can_report_missing_interface(self):
        report = audit.Checks(snapshot(interfaces=[row(name="ether1")]), untrusted=("ether3",)).run()
        self.assertIn("INTERFACE-NOT-FOUND", {f["id"] for f in report["findings"]})

    def test_failed_inventory_not_used_even_if_rows_present(self):
        data = snapshot(interfaces=[row(name="ether1")])
        data["errors"]["interfaces"] = "permission denied"
        report = audit.Checks(data, untrusted=("ether3",)).run()
        self.assertNotIn("INTERFACE-NOT-FOUND", {f["id"] for f in report["findings"]})

    def test_incomplete_report_exit_bit(self):
        report = audit.Checks(snapshot()).run(today=date(2026, 9, 6))
        self.assertEqual(report["exit_code"], 2)
        self.assertNotIn("SAFE", report["verdict"])

    def test_findings_plus_gaps_exit_bits(self):
        data = snapshot()
        data["routeros_version"] = "7.24.1"
        report = audit.Checks(data).run(today=date(2026, 9, 6))
        self.assertEqual(report["exit_code"], 3)

    def test_old_catalog_unknown(self):
        report = audit.Checks(snapshot()).run(today=date(2026, 9, 14))
        self.assertEqual(next(f for f in report["findings"] if f["id"] == "CATALOG")["status"], "UNKNOWN")

    def test_future_catalog_unknown(self):
        report = audit.Checks(snapshot()).run(today=date(2026, 9, 1))
        self.assertEqual(next(f for f in report["findings"] if f["id"] == "CATALOG")["status"], "UNKNOWN")

    def test_offline_not_falsely_authenticated(self):
        report = audit.Checks(snapshot()).run(offline=True)
        self.assertEqual(report["source"], "offline_unverified")

    def test_private_file_no_overwrite(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "report.json"
            audit.write_private(path, {"value": 1})
            with self.assertRaises(FileExistsError):
                audit.write_private(path, {"value": 2})
            self.assertEqual(json.loads(path.read_text())["value"], 1)
            if os.name == "posix":
                self.assertEqual(path.stat().st_mode & 0o777, 0o600)

    @unittest.skipUnless(os.name == "posix", "POSIX symlink test")
    def test_symlink_output_refused(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "link.json"
            target = Path(directory) / "target.json"
            path.symlink_to(target)
            with self.assertRaises(FileExistsError):
                audit.write_private(path, {})
            self.assertFalse(target.exists())

    def test_terminal_control_sanitized(self):
        value = audit.safe_text("a\x1b[31m\r\u202eb")
        self.assertNotIn("\x1b", value)
        self.assertNotIn("\r", value)
        self.assertNotIn("\u202e", value)

    def test_console_ukrainian_evidence_readable(self):
        report = audit.Checks(snapshot()).run(today=date(2026, 9, 6))
        report["findings"][0]["status"] = "REVIEW"
        report["findings"][0]["evidence"] = {"detail": "Невідомо\u202e"}
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            audit.console_report(report)
        self.assertIn("Невідомо", output.getvalue())
        self.assertNotIn("\u202e", output.getvalue())

    def test_offline_cli_end_to_end(self):
        with tempfile.TemporaryDirectory() as directory:
            source, destination = Path(directory) / "snapshot.json", Path(directory) / "report.json"
            audit.write_private(source, snapshot())
            with contextlib.redirect_stdout(io.StringIO()):
                status = audit.main(["--offline", str(source), "--report", str(destination)])
            report = json.loads(destination.read_text())
            self.assertEqual(status, 2)
            self.assertEqual(report["source"], "offline_unverified")
            self.assertEqual(len(report["snapshot_sha256"]), 64)

    def test_existing_report_fails_before_network(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "report.json"
            audit.write_private(path, {})
            with patch.object(audit, "collect") as collect, contextlib.redirect_stderr(io.StringIO()):
                code = audit.main(["--host", "192.0.2.1", "--user", "auditor", "--report", str(path)])
            self.assertEqual(code, 2)
            collect.assert_not_called()


if __name__ == "__main__":
    unittest.main()
