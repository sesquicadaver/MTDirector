# Перевірка 1.0.2 та живий прогін CHR

Дата: 2026-09-06. Середовище: Linux, Python 3.12.13,
OpenSSH 9.6p1 Ubuntu-3ubuntu13.14.

## Локальні результати

- `python3 -m unittest discover -s tests -q`: **123 tests, OK**.
- `python3 -m compileall -q mikrotik_audit.py tests/test_audit.py`: exit 0.
- `python3 mikrotik_audit.py --help`: exit 0.
- Синтетичний offline snapshot → CLI → новий приватний JSON: пройдено.
  Очікуваний код аудитора — 3: знахідки та неповне покриття.
- Реальний локальний subprocess: перевірені stdout/stderr, timeout, обмеження
  розміру та ненульовий exit. Тести не підключаються до маршрутизатора.
- `ssh -G`: параметри перевірені справжнім OpenSSH без мережевого підключення.
- Негативні тести підтверджують, що невідомі поля/стани firewall, відсутня chain,
  умовний accept, помилки збору та обірвані відповіді не стають доказом безпеки.
- Локальні файли не перезаписуються; перевірено POSIX 0600 і відмову для symlink.

## Живий прогін 1.0.2 на CHR 7.16.2

GNS3-проєкт `MTDirector-minlab`, чотири CHR (x86_64, `board-name` CHR QEMU),
management `10.255.10.0/24`. JSON у `/tmp/mikrotik-audit-lab-run-1.0.2-chr/out/`.
Host keys перевірені заздалегідь; `--ask-password` через OpenSSH `SSH_ASKPASS`
(пароль не в CLI). Timeout 300 с. Seed: `--untrusted-interface ether3` і
`ether4`. Усі вузли: `--trusted-network 10.255.10.0/24`.

| Вузол | IP | exit | data | помилки збору | PLAINTEXT-SERVICE | www disabled |
| --- | --- | --- | --- | --- | --- | --- |
| seed | 10.255.10.10 | 3 | 32 розділи | лише `routerboard` | telnet, ftp | true |
| vrrp-a | 10.255.10.11 | 3 | 32 розділи | лише `routerboard` | telnet, ftp, www | false |
| vrrp-b | 10.255.10.12 | 3 | 32 розділи | лише `routerboard` | telnet, ftp, www | false |
| peer | 10.255.10.13 | 3 | 32 розділи | лише `routerboard` | telnet, ftp, www | false |

На всіх чотирьох: `collection_format=json-string-prefix-v1`, RouterOS
`7.16.2 (stable)`, `ROS-2026-09 VULNERABLE_VERSION`, `ROUTERBOOT UNKNOWN`
(меню `/system/routerboard` на CHR — parse error, колонка 1184; `:do on-error`
його не ловить). Решта розділів, включно з `services`, `dns`, `ssh`,
`device_mode`, зібрані. Exit 3 очікуваний (`COVERAGE-LIMIT` + знахідки).

Конфігурацію RouterOS аудитор не змінював.

## Критерії виправлення 1.0.1/1.0.2

| Критерій | Свіжий доказ | Межа доказу |
| --- | --- | --- |
| Немає залежності від нової JSON-опції | Команди проби/колектора не містять опції; жива проба на 7.16.2 пройшла | Інші гілки RouterOS не проганялись |
| Немає втрати числових рядків, boolean і списків | Контрактні тести wire-протоколу; негативні проби з `"001"→1` і `true→1` | Кодек на RouterOS не емулюється повністю |
| Проба перед збором | Тести version → probe → chunks; на CHR `collection_format` присутній | — |
| Ліміт однорядкової команди | Фрагменти ≤ 12000; на CHR три робочі фрагменти без колонки 18400 | Інші образи/версії можуть мати інший ліміт |
| Немає витоку `count-only` | Колектор без `print count-only`; живий stdout парситься | — |
| Невдалий фрагмент не зносить інші | `routerboard` окремо; 32 розділи збережено | Інші невідомі меню не ізольовані автоматично |
| Немає хибного INTERFACE-NOT-FOUND | Недоступна таблиця → INVENTORY UNKNOWN | Перевірена логіка звіту |
| Старі snapshot придатні | Offline-читається схема 1 | Відсутні старі дані не відновлюються |
| Загальний timeout не розширено пробою | Проба входить у спільний бюджет | Внутрішня операція RouterOS не контролюється |

## Що ці результати не доводять

Не перевірено інші версії RouterOS, матрицю прав, macOS/Windows, залізне
RouterBOARD (там `/system/routerboard` має парситись) і доступність служб
із зовнішньої мережі. Каталог містить лише шість CVE з README; firewall —
обмежена статична модель. Це не сертифікований сканер і не гарантія
відсутності вразливостей чи компрометації.
